/*jslint */
/*global AdobeEdge: false, window: false, document: false, console:false, alert: false */
(function (compId) {

    "use strict";
    var im='images/',
        aud='media/',
        vid='media/',
        js='js/',
        fonts = {
        },
        opts = {
            'gAudioPreloadPreference': 'auto',
            'gVideoPreloadPreference': 'auto'
        },
        resources = [
        ],
        scripts = [
        ],
        symbols = {
            "stage": {
                version: "5.0.0",
                minimumCompatibleVersion: "5.0.0",
                build: "5.0.0.375",
                scaleToFit: "none",
                centerStage: "none",
                resizeInstances: false,
                content: {
                    dom: [
                        {
                            id: 'Rectangle7',
                            type: 'rect',
                            rect: ['21px', '8px', '503px', '68px', 'auto', 'auto'],
                            fill: ["rgba(0,222,245,1)"],
                            stroke: [0,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'Text2',
                            type: 'text',
                            rect: ['28px', '12px', 'auto', 'auto', 'auto', 'auto'],
                            text: "Selamat datang di website interaktif tentang<br>",
                            align: "left",
                            font: ['Trebuchet MS, Arial, Helvetica, sans-serif', [24, "px"], "rgba(0,0,0,1)", "400", "none solid rgb(0, 0, 0)", "normal", "break-word", "nowrap"]
                        },
                        {
                            id: 'Text3',
                            type: 'text',
                            rect: ['201px', '41px', 'auto', 'auto', 'auto', 'auto'],
                            text: "Kapasitor",
                            align: "left",
                            font: ['\'Trebuchet MS\', Arial, Helvetica, sans-serif', [24, "px"], "rgba(0,0,0,1)", "400", "none solid rgb(0, 0, 0)", "normal", "break-word", "nowrap"]
                        },
                        {
                            id: 'Rectangle9',
                            type: 'rect',
                            rect: ['563px', '91px', '488px', '52px', 'auto', 'auto'],
                            fill: ["rgba(179,228,233,1.00)"],
                            stroke: [0,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'Text4',
                            type: 'text',
                            rect: ['152px', '102px', 'auto', 'auto', 'auto', 'auto'],
                            text: "PILIH  JENIS SUSUNAN",
                            align: "left",
                            font: ['\'Trebuchet MS\', Arial, Helvetica, sans-serif', [24, "px"], "rgba(0,0,0,1)", "400", "none solid rgb(0, 0, 0)", "normal", "break-word", "nowrap"]
                        },
                        {
                            id: 'Rectangle10',
                            type: 'rect',
                            rect: ['568px', '160px', '194px', '176px', 'auto', 'auto'],
                            fill: ["rgba(179,228,233,1)"],
                            stroke: [0,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'Rectangle10Copy2',
                            type: 'rect',
                            rect: ['579px', '160px', '194px', '176px', 'auto', 'auto'],
                            fill: ["rgba(179,228,233,1)"],
                            stroke: [0,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'Text5',
                            type: 'text',
                            rect: ['43px', '168px', '180px', '29px', 'auto', 'auto'],
                            text: "SUSUNAN PARALEL",
                            align: "left",
                            font: ['\'Trebuchet MS\', Arial, Helvetica, sans-serif', [21, "px"], "rgba(0,0,0,1)", "400", "none solid rgb(0, 0, 0)", "normal", "break-word", ""]
                        },
                        {
                            id: 'Text5Copy',
                            type: 'text',
                            rect: ['602px', '168px', '148px', '29px', 'auto', 'auto'],
                            text: "SUSUNAN SERI",
                            align: "left",
                            font: ['\'Trebuchet MS\', Arial, Helvetica, sans-serif', [21, "px"], "rgba(0,0,0,1)", "400", "none solid rgb(0, 0, 0)", "normal", "break-word", ""]
                        },
                        {
                            id: 'lampu2',
                            type: 'image',
                            rect: ['66px', '424px', '110px', '110px', 'auto', 'auto'],
                            cursor: 'pointer',
                            fill: ["rgba(0,0,0,0)",im+"lampu2.png",'0px','0px']
                        },
                        {
                            id: 'lampu_1',
                            type: 'image',
                            rect: ['358px', '424px', '110px', '110px', 'auto', 'auto'],
                            cursor: 'pointer',
                            fill: ["rgba(0,0,0,0)",im+"lampu%201.png",'0px','0px']
                        },
                        {
                            id: 'Rectangle2',
                            type: 'rect',
                            rect: ['93px', '412px', '358px', '38px', 'auto', 'auto'],
                            fill: ["rgba(251,251,135,1.00)"],
                            stroke: [0,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'Text',
                            type: 'text',
                            rect: ['231px', '416px', '85px', '29px', 'auto', 'auto'],
                            text: "FYP 34",
                            font: ['Lucida Sans Unicode, Lucida Grande, sans-serif', [25, "px"], "rgba(0,0,0,1)", "normal", "none", "italic", "break-word", ""]
                        }
                    ],
                    style: {
                        '${Stage}': {
                            isStage: true,
                            rect: ['null', 'null', '550px', '400px', 'auto', 'auto'],
                            sizeRange: ['4px','','',''],
                            overflow: 'hidden',
                            fill: ["rgba(255,255,255,1)"]
                        }
                    }
                },
                timeline: {
                    duration: 5500,
                    autoPlay: true,
                    data: [
                        [
                            "eid54",
                            "left",
                            3000,
                            1000,
                            "linear",
                            "${Text5}",
                            '578px',
                            '43px'
                        ],
                        [
                            "eid34",
                            "left",
                            0,
                            2000,
                            "linear",
                            "${Text3}",
                            '743px',
                            '201px'
                        ],
                        [
                            "eid79",
                            "left",
                            5000,
                            500,
                            "linear",
                            "${lampu_1}",
                            '352px',
                            '358px'
                        ],
                        [
                            "eid55",
                            "left",
                            3000,
                            1000,
                            "linear",
                            "${Rectangle10}",
                            '568px',
                            '33px'
                        ],
                        [
                            "eid58",
                            "left",
                            3995,
                            1005,
                            "linear",
                            "${Rectangle10Copy2}",
                            '579px',
                            '316px'
                        ],
                        [
                            "eid51",
                            "left",
                            2000,
                            1000,
                            "linear",
                            "${Rectangle9}",
                            '563px',
                            '28px'
                        ],
                        [
                            "eid50",
                            "left",
                            2000,
                            1000,
                            "linear",
                            "${Text4}",
                            '687px',
                            '152px'
                        ],
                        [
                            "eid59",
                            "height",
                            3000,
                            0,
                            "linear",
                            "${Rectangle10Copy2}",
                            '176px',
                            '176px'
                        ],
                        [
                            "eid82",
                            "top",
                            5000,
                            500,
                            "linear",
                            "${Rectangle2}",
                            '412px',
                            '351px'
                        ],
                        [
                            "eid57",
                            "left",
                            3995,
                            1005,
                            "linear",
                            "${Text5Copy}",
                            '602px',
                            '339px'
                        ],
                        [
                            "eid27",
                            "top",
                            0,
                            0,
                            "linear",
                            "${Rectangle7}",
                            '8px',
                            '8px'
                        ],
                        [
                            "eid78",
                            "top",
                            5000,
                            500,
                            "linear",
                            "${lampu2}",
                            '424px',
                            '212px'
                        ],
                        [
                            "eid32",
                            "left",
                            0,
                            2000,
                            "linear",
                            "${Text2}",
                            '570px',
                            '28px'
                        ],
                        [
                            "eid33",
                            "left",
                            0,
                            2000,
                            "linear",
                            "${Rectangle7}",
                            '563px',
                            '21px'
                        ],
                        [
                            "eid25",
                            "top",
                            0,
                            0,
                            "linear",
                            "${Text2}",
                            '12px',
                            '12px'
                        ],
                        [
                            "eid81",
                            "top",
                            5000,
                            500,
                            "linear",
                            "${Text}",
                            '416px',
                            '355px'
                        ],
                        [
                            "eid80",
                            "top",
                            5000,
                            500,
                            "linear",
                            "${lampu_1}",
                            '424px',
                            '212px'
                        ],
                        [
                            "eid60",
                            "height",
                            3000,
                            0,
                            "linear",
                            "${Rectangle10}",
                            '176px',
                            '176px'
                        ]
                    ]
                }
            }
        };

    AdobeEdge.registerCompositionDefn(compId, symbols, fonts, scripts, resources, opts);

    if (!window.edge_authoring_mode) AdobeEdge.getComposition(compId).load("animasi_edgeActions.js");
})("EDGE-444686877");
