/*jslint */
/*global AdobeEdge: false, window: false, document: false, console:false, alert: false */
(function (compId) {

    "use strict";
    var im='images/',
        aud='media/',
        vid='media/',
        js='js/',
        fonts = {
        },
        opts = {
            'gAudioPreloadPreference': 'auto',
            'gVideoPreloadPreference': 'auto'
        },
        resources = [
        ],
        scripts = [
        ],
        symbols = {
            "stage": {
                version: "5.0.0",
                minimumCompatibleVersion: "5.0.0",
                build: "5.0.0.375",
                scaleToFit: "none",
                centerStage: "none",
                resizeInstances: false,
                content: {
                    dom: [
                        {
                            id: 'RectangleCopy3',
                            type: 'rect',
                            rect: ['243px', '306px', '25px', '87px', 'auto', 'auto'],
                            opacity: 1,
                            fill: ["rgba(192,192,192,1)"],
                            stroke: [0,"rgba(0,0,0,1)","none"]
                        },
                        {
                            id: 'RectangleCopy8',
                            type: 'rect',
                            rect: ['321px', '347px', '5px', '10px', 'auto', 'auto'],
                            opacity: 1,
                            fill: ["rgba(192,192,192,1)"],
                            stroke: [0,"rgba(0,0,0,1)","none"]
                        },
                        {
                            id: 'RectangleCopy2',
                            type: 'rect',
                            rect: ['297px', '306px', '25px', '87px', 'auto', 'auto'],
                            opacity: 1,
                            fill: ["rgba(192,192,192,1)"],
                            stroke: [0,"rgba(0,0,0,1)","none"]
                        },
                        {
                            id: 'Rectangle2Copy9',
                            type: 'rect',
                            rect: ['44px', '236px', '478px', '3px', 'auto', 'auto'],
                            opacity: 1,
                            fill: ["rgba(0,0,0,1.00)"],
                            stroke: [0,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'Rectangle2Copy8',
                            type: 'rect',
                            rect: ['44px', '119px', '478px', '3px', 'auto', 'auto'],
                            opacity: 1,
                            fill: ["rgba(0,0,0,1.00)"],
                            stroke: [0,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'Rectangle2Copy7',
                            type: 'rect',
                            rect: ['322px', '351px', '199px', '3px', 'auto', 'auto'],
                            opacity: 1,
                            fill: ["rgba(0,0,0,1.00)"],
                            stroke: [0,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'Rectangle2',
                            type: 'rect',
                            rect: ['322px', '373px', '110px', '3px', 'auto', 'auto'],
                            opacity: 1,
                            fill: ["rgba(0,0,0,1.00)"],
                            stroke: [0,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'Rectangle2Copy6',
                            type: 'rect',
                            rect: ['123px', '373px', '120px', '3px', 'auto', 'auto'],
                            opacity: 1,
                            fill: ["rgba(0,0,0,1.00)"],
                            stroke: [0,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'Rectangle2Copy3',
                            type: 'rect',
                            rect: ['319px', '512px', '113px', '3px', 'auto', 'auto'],
                            opacity: 1,
                            fill: ["rgba(0,0,0,1.00)"],
                            stroke: [0,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'Rectangle2Copy5',
                            type: 'rect',
                            rect: ['124px', '512px', '113px', '3px', 'auto', 'auto'],
                            opacity: 1,
                            fill: ["rgba(0,0,0,1.00)"],
                            stroke: [0,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'Rectangle4Copy3',
                            type: 'rect',
                            rect: ['44px', '119px', '3px', '235px', 'auto', 'auto'],
                            opacity: 1,
                            fill: ["rgba(0,0,0,1)"],
                            stroke: [0,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'Rectangle4Copy2',
                            type: 'rect',
                            rect: ['519px', '119px', '3px', '235px', 'auto', 'auto'],
                            opacity: 1,
                            fill: ["rgba(0,0,0,1)"],
                            stroke: [0,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'Rectangle4',
                            type: 'rect',
                            rect: ['429px', '373px', '3px', '141px', 'auto', 'auto'],
                            opacity: 1,
                            fill: ["rgba(0,0,0,1)"],
                            stroke: [0,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'Rectangle4Copy',
                            type: 'rect',
                            rect: ['123px', '374px', '3px', '141px', 'auto', 'auto'],
                            opacity: 1,
                            fill: ["rgba(0,0,0,1)"],
                            stroke: [0,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'Rectangle5Copy3',
                            type: 'rect',
                            rect: ['276px', '208px', '14px', '30px', 'auto', 'auto'],
                            opacity: 1,
                            fill: ["rgba(112,106,106,1.00)"],
                            stroke: [0,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'Rectangle5Copy2',
                            type: 'rect',
                            rect: ['273px', '91px', '14px', '30px', 'auto', 'auto'],
                            opacity: 1,
                            fill: ["rgba(112,106,106,1.00)"],
                            stroke: [0,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'EllipseCopy8',
                            type: 'ellipse',
                            rect: ['270px', '173px', '25px', '42px', 'auto', 'auto'],
                            borderRadius: ["50%", "50%", "50%", "50%"],
                            opacity: 1,
                            fill: ["rgba(209,209,209,1.00)"],
                            stroke: [0,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'EllipseCopy9',
                            type: 'ellipse',
                            rect: ['268px', '54px', '25px', '42px', 'auto', 'auto'],
                            borderRadius: ["50%", "50%", "50%", "50%"],
                            opacity: 1,
                            fill: ["rgba(209,209,209,1)"],
                            stroke: [0,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'Rectangle3Copy',
                            type: 'rect',
                            rect: ['237px', '507px', '7px', '13px', 'auto', 'auto'],
                            fill: ["rgba(0,0,0,1)"],
                            stroke: [0,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'Rectangle',
                            type: 'rect',
                            rect: ['242px', '508px', '40px', '9px', 'auto', 'auto'],
                            fill: ["rgba(255,0,0,1)"],
                            stroke: [1,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'RectangleCopy',
                            type: 'rect',
                            rect: ['285px', '508px', '40px', '9px', 'auto', 'auto'],
                            fill: ["rgba(192,192,192,1.00)"],
                            stroke: [1,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'EllipseCopy15',
                            type: 'ellipse',
                            rect: ['244px', '499px', '7px', '30px', 'auto', 'auto'],
                            borderRadius: ["50%", "50%", "50%", "50%"],
                            fill: ["rgba(228,159,7,1.00)"],
                            stroke: [0,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'EllipseCopy13',
                            type: 'ellipse',
                            rect: ['316px', '499px', '7px', '30px', 'auto', 'auto'],
                            borderRadius: ["50%", "50%", "50%", "50%"],
                            fill: ["rgba(228,159,7,1.00)"],
                            stroke: [0,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'RoundRectCopy',
                            type: 'rect',
                            rect: ['244px', '499px', '79px', '30px', 'auto', 'auto'],
                            borderRadius: ["10px", "10px", "10px", "10px"],
                            fill: ["rgba(228,159,7,1.00)"],
                            stroke: [0,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'RoundRectCopy2',
                            type: 'rect',
                            rect: ['139px', '498px', '35px', '28px', 'auto', 'auto'],
                            borderRadius: ["10px", "10px", "10px", "10px"],
                            fill: ["rgba(192,192,192,1)"],
                            stroke: [1,"rgb(0, 0, 0)","solid"]
                        },
                        {
                            id: 'Ellipse8',
                            type: 'ellipse',
                            rect: ['144px', '501px', '23px', '20px', 'auto', 'auto'],
                            cursor: 'pointer',
                            borderRadius: ["50%", "50%", "50%", "50%"],
                            fill: ["rgba(255,0,0,1)"],
                            stroke: [1,"rgb(0, 0, 0)","solid"]
                        },
                        {
                            id: 'Rectangle3',
                            type: 'rect',
                            rect: ['451px', '373px', '88px', '40px', 'auto', 'auto'],
                            fill: ["rgba(255,255,255,1.00)"],
                            stroke: [1,"rgb(0, 0, 0)","solid"]
                        },
                        {
                            id: 'Rectangle3Copy3',
                            type: 'rect',
                            rect: ['451px', '424px', '88px', '40px', 'auto', 'auto'],
                            fill: ["rgba(255,255,255,1.00)"],
                            stroke: [1,"rgb(0, 0, 0)","solid"]
                        },
                        {
                            id: 'Rectangle5',
                            type: 'rect',
                            rect: ['457px', '379px', '77px', '9px', 'auto', 'auto'],
                            fill: ["rgba(255,0,0,1.00)"],
                            stroke: [1,"rgb(0, 0, 0)","solid"]
                        },
                        {
                            id: 'Rectangle5Copy4',
                            type: 'rect',
                            rect: ['457px', '430px', '77px', '9px', 'auto', 'auto'],
                            fill: ["rgba(47,255,0,1.00)"],
                            stroke: [1,"rgb(0, 0, 0)","solid"]
                        },
                        {
                            id: 'Text',
                            type: 'text',
                            rect: ['470px', '393px', 'auto', 'auto', 'auto', 'auto'],
                            text: "Elektron",
                            font: ['Arial, Helvetica, sans-serif', [15, "px"], "rgba(0,0,0,1)", "normal", "none", "", "break-word", "nowrap"]
                        },
                        {
                            id: 'TextCopy2',
                            type: 'text',
                            rect: ['470px', '444px', 'auto', 'auto', 'auto', 'auto'],
                            text: "Proton",
                            font: ['Arial, Helvetica, sans-serif', [15, "px"], "rgba(0,0,0,1)", "normal", "none", "", "break-word", "nowrap"]
                        },
                        {
                            id: 'Rectangle2Copy11',
                            type: 'rect',
                            rect: ['44px', '351px', '199px', '3px', 'auto', 'auto'],
                            opacity: 1,
                            fill: ["rgba(0,0,0,1.00)"],
                            stroke: [0,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'RectangleCopy9',
                            type: 'rect',
                            rect: ['240px', '234px', '5px', '10px', 'auto', 'auto'],
                            opacity: 1,
                            fill: ["rgba(192,192,192,1)"],
                            stroke: [0,"rgba(0,0,0,1)","none"]
                        },
                        {
                            id: 'RectangleCopy10',
                            type: 'rect',
                            rect: ['240px', '234px', '5px', '10px', 'auto', 'auto'],
                            opacity: 1,
                            fill: ["rgba(192,192,192,1)"],
                            stroke: [0,"rgba(0,0,0,1)","none"]
                        },
                        {
                            id: 'Rectangle2Copy14',
                            type: 'rect',
                            rect: ['69px', '326px', '44px', '44px', 'auto', 'auto'],
                            fill: ["rgba(192,192,192,1)"],
                            stroke: [1,"rgba(0,0,0,1)","solid"]
                        },
                        {
                            id: 'EllipseCopy19',
                            type: 'ellipse',
                            rect: ['76px', '335px', '27px', '28px', 'auto', 'auto'],
                            cursor: 'pointer',
                            borderRadius: ["50%", "50%", "50%", "50%"],
                            fill: ["rgba(255,0,0,1.00)"],
                            stroke: [1,"rgb(0, 0, 0)","solid"]
                        },
                        {
                            id: 'Rectangle8',
                            type: 'rect',
                            rect: ['50px', '536px', '220px', '22px', 'auto', 'auto'],
                            fill: ["rgba(192,192,192,1)"],
                            stroke: [0,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'Text2',
                            type: 'text',
                            rect: ['50px', '539px', 'auto', 'auto', 'auto', 'auto'],
                            text: "Klik tombol untuk megisi kapasitor",
                            align: "left",
                            font: ['Arial, Helvetica, sans-serif', [15, "px"], "rgba(0,0,0,1)", "400", "none solid rgb(0, 0, 0)", "normal", "break-word", "nowrap"]
                        },
                        {
                            id: 'Rectangle9',
                            type: 'rect',
                            rect: ['-262px', '265px', '243px', '22px', 'auto', 'auto'],
                            fill: ["rgba(192,192,192,1)"],
                            stroke: [0,"rgb(0, 0, 0)","none"]
                        },
                        {
                            id: 'Text3',
                            type: 'text',
                            rect: ['-262px', '267px', 'auto', 'auto', 'auto', 'auto'],
                            text: "Klik tombol untuk menyalakan lampu",
                            align: "left",
                            font: ['Arial, Helvetica, sans-serif', [15, "px"], "rgba(0,0,0,1)", "400", "none solid rgb(0, 0, 0)", "normal", "break-word", "nowrap"]
                        },
                        {
                            id: 'Rectangle10',
                            type: 'rect',
                            rect: ['-289px', '407px', '274px', '43px', 'auto', 'auto'],
                            fill: ["rgba(203,203,203,1.00)"],
                            stroke: [1,"rgb(0, 0, 0)","solid"]
                        },
                        {
                            id: 'Text5',
                            type: 'text',
                            rect: ['-285px', '413px', 'auto', 'auto', 'auto', 'auto'],
                            text: "Baterai mengisi kapasitor dengan muatan <br>elektron dan proton",
                            align: "left",
                            font: ['Arial, Helvetica, sans-serif', [15, "px"], "rgba(0,0,0,1)", "400", "none solid rgb(0, 0, 0)", "normal", "break-word", "nowrap"]
                        },
                        {
                            id: 'Rectangle12',
                            type: 'rect',
                            rect: ['-260px', '127px', '241px', '40px', 'auto', 'auto'],
                            fill: ["rgba(203,203,203,1)"],
                            stroke: [1,"rgb(0, 0, 0)","solid"]
                        },
                        {
                            id: 'Rectangle12Copy',
                            type: 'rect',
                            rect: ['-258px', '127px', '248px', '40px', 'auto', 'auto'],
                            fill: ["rgba(203,203,203,1)"],
                            stroke: [1,"rgb(0, 0, 0)","solid"]
                        },
                        {
                            id: 'Text6',
                            type: 'text',
                            rect: ['-253px', '131px', '229px', '34px', 'auto', 'auto'],
                            text: "Elektron bergerak menuju proton  <br>yang menyebabkan lampu menyala",
                            align: "left",
                            font: ['Arial, Helvetica, sans-serif', [15, "px"], "rgba(0,0,0,1)", "400", "none solid rgb(0, 0, 0)", "normal", "break-word", ""]
                        },
                        {
                            id: 'Text6Copy2',
                            type: 'text',
                            rect: ['-251px', '131px', '243px', '34px', 'auto', 'auto'],
                            text: "Apabila jumlah elektron sama dengan proton maka lampu akan mati",
                            align: "left",
                            font: ['Arial, Helvetica, sans-serif', [15, "px"], "rgba(0,0,0,1)", "400", "none solid rgb(0, 0, 0)", "normal", "break-word", ""]
                        },
                        {
                            id: 'Rectangle13',
                            type: 'rect',
                            rect: ['-26px', '6px', '129px', '28px', 'auto', 'auto'],
                            fill: ["rgba(236,236,68,1.00)"],
                            stroke: [1,"rgb(0, 0, 0)","solid"]
                        },
                        {
                            id: 'Text7',
                            type: 'text',
                            rect: ['10px', '6px', 'auto', 'auto', 'auto', 'auto'],
                            text: "FYP 34",
                            align: "left",
                            font: ['Arial, Helvetica, sans-serif', [25, "px"], "rgba(0,0,0,1)", "400", "none solid rgb(0, 0, 0)", "normal", "break-word", "nowrap"]
                        },
                        {
                            id: 'Rectangle6',
                            type: 'rect',
                            rect: ['115px', '6px', '266px', '30px', 'auto', 'auto'],
                            fill: ["rgba(150,236,134,1.00)"],
                            stroke: [0,"rgba(0,0,0,1)","none"]
                        },
                        {
                            id: 'Text4',
                            type: 'text',
                            rect: ['134px', '8px', 'auto', 'auto', 'auto', 'auto'],
                            text: "SUSUNAN PARALEL",
                            font: ['Arial, Helvetica, sans-serif', [24, ""], "rgba(0,0,0,1)", "normal", "none", "", "break-word", "nowrap"]
                        },
                        {
                            id: 'RoundRect',
                            type: 'rect',
                            rect: ['455px', '490px', '79px', '30px', 'auto', 'auto'],
                            borderRadius: ["10px", "10px", "10px", "10px"],
                            fill: ["rgba(236,182,182,1.00)"],
                            stroke: [1,"rgba(0,0,0,1)","solid"]
                        },
                        {
                            id: 'Text9',
                            type: 'text',
                            rect: ['461px', '493px', 'auto', 'auto', 'auto', 'auto'],
                            cursor: 'pointer',
                            text: "HOME",
                            align: "left",
                            font: ['Arial, Helvetica, sans-serif', [24, "px"], "rgba(0,0,0,1)", "400", "none solid rgb(0, 0, 0)", "normal", "break-word", "nowrap"]
                        }
                    ],
                    style: {
                        '${Stage}': {
                            isStage: true,
                            rect: ['null', 'null', '550px', '573px', 'auto', 'auto'],
                            overflow: 'visible',
                            fill: ["rgba(255,255,255,1)"]
                        }
                    }
                },
                timeline: {
                    duration: 26000,
                    autoPlay: false,
                    data: [
                        [
                            "eid428",
                            "width",
                            1000,
                            250,
                            "linear",
                            "${RectangleCopy}",
                            '40px',
                            '12px'
                        ],
                        [
                            "eid448",
                            "width",
                            3750,
                            500,
                            "linear",
                            "${RectangleCopy}",
                            '12px',
                            '44px'
                        ],
                        [
                            "eid451",
                            "width",
                            5000,
                            500,
                            "linear",
                            "${RectangleCopy}",
                            '44px',
                            '12px'
                        ],
                        [
                            "eid545",
                            "background-color",
                            15000,
                            250,
                            "linear",
                            "${RectangleCopy10}",
                            'rgba(192,192,192,1)',
                            'rgba(255,0,0,1.00)'
                        ],
                        [
                            "eid643",
                            "background-color",
                            23000,
                            250,
                            "linear",
                            "${RectangleCopy10}",
                            'rgba(255,0,0,1)',
                            'rgba(192,192,192,1.00)'
                        ],
                        [
                            "eid549",
                            "left",
                            15250,
                            500,
                            "linear",
                            "${RectangleCopy9}",
                            '240px',
                            '199px'
                        ],
                        [
                            "eid554",
                            "left",
                            15750,
                            750,
                            "linear",
                            "${RectangleCopy9}",
                            '199px',
                            '134px'
                        ],
                        [
                            "eid566",
                            "left",
                            16500,
                            500,
                            "linear",
                            "${RectangleCopy9}",
                            '134px',
                            '40px'
                        ],
                        [
                            "eid570",
                            "left",
                            17500,
                            87,
                            "linear",
                            "${RectangleCopy9}",
                            '40px',
                            '41px'
                        ],
                        [
                            "eid572",
                            "left",
                            17587,
                            50,
                            "linear",
                            "${RectangleCopy9}",
                            '41px',
                            '42px'
                        ],
                        [
                            "eid596",
                            "left",
                            19750,
                            750,
                            "linear",
                            "${RectangleCopy9}",
                            '42px',
                            '271px'
                        ],
                        [
                            "eid602",
                            "left",
                            20500,
                            250,
                            "linear",
                            "${RectangleCopy9}",
                            '271px',
                            '475px'
                        ],
                        [
                            "eid604",
                            "left",
                            20750,
                            250,
                            "linear",
                            "${RectangleCopy9}",
                            '475px',
                            '513px'
                        ],
                        [
                            "eid608",
                            "left",
                            21000,
                            78,
                            "linear",
                            "${RectangleCopy9}",
                            '513px',
                            '514px'
                        ],
                        [
                            "eid626",
                            "left",
                            22250,
                            250,
                            "linear",
                            "${RectangleCopy9}",
                            '514px',
                            '492px'
                        ],
                        [
                            "eid629",
                            "left",
                            22500,
                            500,
                            "linear",
                            "${RectangleCopy9}",
                            '492px',
                            '307px'
                        ],
                        [
                            "eid635",
                            "background-color",
                            15500,
                            250,
                            "linear",
                            "${Rectangle}",
                            'rgba(255,0,0,1)',
                            'rgba(192,192,192,1.00)'
                        ],
                        [
                            "eid468",
                            "background-color",
                            0,
                            0,
                            "linear",
                            "${Rectangle3}",
                            'rgba(255,255,255,1.00)',
                            'rgba(255,255,255,1.00)'
                        ],
                        [
                            "eid426",
                            "width",
                            1000,
                            250,
                            "linear",
                            "${Rectangle}",
                            '40px',
                            '12px'
                        ],
                        [
                            "eid446",
                            "width",
                            3750,
                            500,
                            "linear",
                            "${Rectangle}",
                            '12px',
                            '44px'
                        ],
                        [
                            "eid453",
                            "width",
                            5000,
                            500,
                            "linear",
                            "${Rectangle}",
                            '44px',
                            '14px'
                        ],
                        [
                            "eid550",
                            "width",
                            15250,
                            500,
                            "linear",
                            "${RectangleCopy9}",
                            '5px',
                            '46px'
                        ],
                        [
                            "eid568",
                            "width",
                            17000,
                            500,
                            "linear",
                            "${RectangleCopy9}",
                            '46px',
                            '7px'
                        ],
                        [
                            "eid593",
                            "width",
                            19250,
                            500,
                            "linear",
                            "${RectangleCopy9}",
                            '7px',
                            '49px'
                        ],
                        [
                            "eid605",
                            "width",
                            20750,
                            250,
                            "linear",
                            "${RectangleCopy9}",
                            '49px',
                            '11px'
                        ],
                        [
                            "eid627",
                            "width",
                            22250,
                            250,
                            "linear",
                            "${RectangleCopy9}",
                            '11px',
                            '33px'
                        ],
                        [
                            "eid631",
                            "width",
                            23000,
                            250,
                            "linear",
                            "${RectangleCopy9}",
                            '33px',
                            '3px'
                        ],
                        [
                            "eid574",
                            "top",
                            17637,
                            363,
                            "linear",
                            "${RectangleCopy10}",
                            '347px',
                            '306px'
                        ],
                        [
                            "eid588",
                            "top",
                            18000,
                            500,
                            "linear",
                            "${RectangleCopy10}",
                            '306px',
                            '233px'
                        ],
                        [
                            "eid590",
                            "top",
                            18500,
                            500,
                            "linear",
                            "${RectangleCopy10}",
                            '233px',
                            '116px'
                        ],
                        [
                            "eid617",
                            "top",
                            21500,
                            500,
                            "linear",
                            "${RectangleCopy10}",
                            '116px',
                            '312px'
                        ],
                        [
                            "eid619",
                            "top",
                            22000,
                            250,
                            "linear",
                            "${RectangleCopy10}",
                            '312px',
                            '347px'
                        ],
                        [
                            "eid576",
                            "top",
                            17637,
                            363,
                            "linear",
                            "${RectangleCopy9}",
                            '347px',
                            '306px'
                        ],
                        [
                            "eid589",
                            "top",
                            18000,
                            500,
                            "linear",
                            "${RectangleCopy9}",
                            '306px',
                            '233px'
                        ],
                        [
                            "eid615",
                            "top",
                            21500,
                            500,
                            "linear",
                            "${RectangleCopy9}",
                            '233px',
                            '315px'
                        ],
                        [
                            "eid621",
                            "top",
                            22000,
                            250,
                            "linear",
                            "${RectangleCopy9}",
                            '315px',
                            '350px'
                        ],
                        [
                            "eid632",
                            "background-color",
                            23000,
                            250,
                            "linear",
                            "${RectangleCopy}",
                            'rgba(47,255,0,1)',
                            'rgba(192,192,192,1.00)'
                        ],
                        [
                            "eid547",
                            "left",
                            15250,
                            500,
                            "linear",
                            "${RectangleCopy10}",
                            '240px',
                            '199px'
                        ],
                        [
                            "eid553",
                            "left",
                            15750,
                            750,
                            "linear",
                            "${RectangleCopy10}",
                            '199px',
                            '134px'
                        ],
                        [
                            "eid565",
                            "left",
                            16500,
                            500,
                            "linear",
                            "${RectangleCopy10}",
                            '134px',
                            '40px'
                        ],
                        [
                            "eid569",
                            "left",
                            17500,
                            87,
                            "linear",
                            "${RectangleCopy10}",
                            '40px',
                            '41px'
                        ],
                        [
                            "eid571",
                            "left",
                            17587,
                            50,
                            "linear",
                            "${RectangleCopy10}",
                            '41px',
                            '42px'
                        ],
                        [
                            "eid595",
                            "left",
                            19750,
                            750,
                            "linear",
                            "${RectangleCopy10}",
                            '42px',
                            '271px'
                        ],
                        [
                            "eid603",
                            "left",
                            20500,
                            250,
                            "linear",
                            "${RectangleCopy10}",
                            '271px',
                            '475px'
                        ],
                        [
                            "eid606",
                            "left",
                            20750,
                            250,
                            "linear",
                            "${RectangleCopy10}",
                            '475px',
                            '513px'
                        ],
                        [
                            "eid609",
                            "left",
                            21000,
                            78,
                            "linear",
                            "${RectangleCopy10}",
                            '513px',
                            '514px'
                        ],
                        [
                            "eid624",
                            "left",
                            22250,
                            250,
                            "linear",
                            "${RectangleCopy10}",
                            '514px',
                            '492px'
                        ],
                        [
                            "eid628",
                            "left",
                            22500,
                            500,
                            "linear",
                            "${RectangleCopy10}",
                            '492px',
                            '307px'
                        ],
                        [
                            "eid720",
                            "left",
                            18000,
                            500,
                            "linear",
                            "${Text6}",
                            '-253px',
                            '163px'
                        ],
                        [
                            "eid722",
                            "left",
                            21750,
                            250,
                            "linear",
                            "${Text6}",
                            '163px',
                            '-269px'
                        ],
                        [
                            "eid724",
                            "left",
                            22500,
                            500,
                            "linear",
                            "${Text6Copy2}",
                            '-251px',
                            '169px'
                        ],
                        [
                            "eid728",
                            "left",
                            25000,
                            1000,
                            "linear",
                            "${Text6Copy2}",
                            '169px',
                            '-276px'
                        ],
                        [
                            "eid431",
                            "height",
                            1250,
                            750,
                            "linear",
                            "${RectangleCopy}",
                            '9px',
                            '40px'
                        ],
                        [
                            "eid445",
                            "height",
                            3500,
                            250,
                            "linear",
                            "${RectangleCopy}",
                            '40px',
                            '11px'
                        ],
                        [
                            "eid465",
                            "height",
                            5675,
                            325,
                            "linear",
                            "${RectangleCopy}",
                            '11px',
                            '63px'
                        ],
                        [
                            "eid432",
                            "top",
                            1250,
                            750,
                            "linear",
                            "${RectangleCopy}",
                            '508px',
                            '477px'
                        ],
                        [
                            "eid437",
                            "top",
                            2000,
                            1000,
                            "linear",
                            "${RectangleCopy}",
                            '477px',
                            '403px'
                        ],
                        [
                            "eid439",
                            "top",
                            3000,
                            500,
                            "linear",
                            "${RectangleCopy}",
                            '403px',
                            '368px'
                        ],
                        [
                            "eid466",
                            "top",
                            5675,
                            325,
                            "linear",
                            "${RectangleCopy}",
                            '368px',
                            '316px'
                        ],
                        [
                            "eid680",
                            "left",
                            1000,
                            500,
                            "linear",
                            "${Text5}",
                            '-285px',
                            '143px'
                        ],
                        [
                            "eid682",
                            "left",
                            5500,
                            500,
                            "linear",
                            "${Text5}",
                            '143px',
                            '-323px'
                        ],
                        [
                            "eid681",
                            "left",
                            1000,
                            500,
                            "linear",
                            "${Rectangle10}",
                            '-289px',
                            '139px'
                        ],
                        [
                            "eid683",
                            "left",
                            5500,
                            500,
                            "linear",
                            "${Rectangle10}",
                            '139px',
                            '-327px'
                        ],
                        [
                            "eid429",
                            "height",
                            1250,
                            750,
                            "linear",
                            "${Rectangle}",
                            '9px',
                            '40px'
                        ],
                        [
                            "eid444",
                            "height",
                            3500,
                            250,
                            "linear",
                            "${Rectangle}",
                            '40px',
                            '11px'
                        ],
                        [
                            "eid463",
                            "height",
                            5675,
                            325,
                            "linear",
                            "${Rectangle}",
                            '11px',
                            '63px'
                        ],
                        [
                            "eid575",
                            "height",
                            17637,
                            363,
                            "linear",
                            "${RectangleCopy9}",
                            '10px',
                            '51px'
                        ],
                        [
                            "eid591",
                            "height",
                            18500,
                            500,
                            "linear",
                            "${RectangleCopy9}",
                            '51px',
                            '11px'
                        ],
                        [
                            "eid611",
                            "height",
                            21078,
                            422,
                            "linear",
                            "${RectangleCopy9}",
                            '11px',
                            '42px'
                        ],
                        [
                            "eid620",
                            "height",
                            22000,
                            250,
                            "linear",
                            "${RectangleCopy9}",
                            '42px',
                            '7px'
                        ],
                        [
                            "eid471",
                            "height",
                            0,
                            0,
                            "linear",
                            "${Rectangle3}",
                            '40px',
                            '40px'
                        ],
                        [
                            "eid721",
                            "left",
                            18000,
                            500,
                            "linear",
                            "${Rectangle12}",
                            '-260px',
                            '156px'
                        ],
                        [
                            "eid723",
                            "left",
                            21750,
                            250,
                            "linear",
                            "${Rectangle12}",
                            '156px',
                            '-276px'
                        ],
                        [
                            "eid548",
                            "width",
                            15250,
                            500,
                            "linear",
                            "${RectangleCopy10}",
                            '5px',
                            '46px'
                        ],
                        [
                            "eid567",
                            "width",
                            17000,
                            500,
                            "linear",
                            "${RectangleCopy10}",
                            '46px',
                            '7px'
                        ],
                        [
                            "eid594",
                            "width",
                            19250,
                            500,
                            "linear",
                            "${RectangleCopy10}",
                            '7px',
                            '49px'
                        ],
                        [
                            "eid607",
                            "width",
                            20750,
                            250,
                            "linear",
                            "${RectangleCopy10}",
                            '49px',
                            '11px'
                        ],
                        [
                            "eid625",
                            "width",
                            22250,
                            250,
                            "linear",
                            "${RectangleCopy10}",
                            '11px',
                            '33px'
                        ],
                        [
                            "eid630",
                            "width",
                            23000,
                            250,
                            "linear",
                            "${RectangleCopy10}",
                            '33px',
                            '3px'
                        ],
                        [
                            "eid422",
                            "left",
                            0,
                            1000,
                            "linear",
                            "${RectangleCopy}",
                            '285px',
                            '395px'
                        ],
                        [
                            "eid427",
                            "left",
                            1000,
                            250,
                            "linear",
                            "${RectangleCopy}",
                            '395px',
                            '423px'
                        ],
                        [
                            "eid436",
                            "left",
                            2000,
                            1000,
                            "linear",
                            "${RectangleCopy}",
                            '423px',
                            '422px'
                        ],
                        [
                            "eid447",
                            "left",
                            3750,
                            500,
                            "linear",
                            "${RectangleCopy}",
                            '422px',
                            '390px'
                        ],
                        [
                            "eid449",
                            "left",
                            4250,
                            750,
                            "linear",
                            "${RectangleCopy}",
                            '390px',
                            '305px'
                        ],
                        [
                            "eid459",
                            "left",
                            5500,
                            175,
                            "linear",
                            "${RectangleCopy}",
                            '305px',
                            '302px'
                        ],
                        [
                            "eid725",
                            "left",
                            22500,
                            500,
                            "linear",
                            "${Rectangle12Copy}",
                            '-258px',
                            '162px'
                        ],
                        [
                            "eid729",
                            "left",
                            25000,
                            1000,
                            "linear",
                            "${Rectangle12Copy}",
                            '162px',
                            '-283px'
                        ],
                        [
                            "eid679",
                            "top",
                            25000,
                            250,
                            "linear",
                            "${Rectangle8}",
                            '536px',
                            '538px'
                        ],
                        [
                            "eid600",
                            "background-color",
                            20000,
                            500,
                            "linear",
                            "${EllipseCopy8}",
                            'rgba(209,209,209,1)',
                            'rgba(255,247,0,1)'
                        ],
                        [
                            "eid675",
                            "background-color",
                            20786,
                            292,
                            "linear",
                            "${EllipseCopy8}",
                            'rgba(255,247,0,1)',
                            'rgba(192,192,192,1.00)'
                        ],
                        [
                            "eid648",
                            "left",
                            5500,
                            500,
                            "linear",
                            "${Text2}",
                            '50px',
                            '-234px'
                        ],
                        [
                            "eid676",
                            "left",
                            25000,
                            250,
                            "linear",
                            "${Text2}",
                            '-234px',
                            '61px'
                        ],
                        [
                            "eid573",
                            "height",
                            17637,
                            363,
                            "linear",
                            "${RectangleCopy10}",
                            '10px',
                            '51px'
                        ],
                        [
                            "eid592",
                            "height",
                            19000,
                            250,
                            "linear",
                            "${RectangleCopy10}",
                            '51px',
                            '11px'
                        ],
                        [
                            "eid610",
                            "height",
                            21078,
                            422,
                            "linear",
                            "${RectangleCopy10}",
                            '11px',
                            '42px'
                        ],
                        [
                            "eid618",
                            "height",
                            22000,
                            250,
                            "linear",
                            "${RectangleCopy10}",
                            '42px',
                            '7px'
                        ],
                        [
                            "eid425",
                            "left",
                            0,
                            1000,
                            "linear",
                            "${Rectangle}",
                            '242px',
                            '118px'
                        ],
                        [
                            "eid450",
                            "left",
                            4250,
                            750,
                            "linear",
                            "${Rectangle}",
                            '118px',
                            '214px'
                        ],
                        [
                            "eid452",
                            "left",
                            5000,
                            500,
                            "linear",
                            "${Rectangle}",
                            '214px',
                            '244px'
                        ],
                        [
                            "eid462",
                            "left",
                            5500,
                            175,
                            "linear",
                            "${Rectangle}",
                            '244px',
                            '249px'
                        ],
                        [
                            "eid662",
                            "left",
                            6000,
                            500,
                            "linear",
                            "${Text3}",
                            '-262px',
                            '54px'
                        ],
                        [
                            "eid664",
                            "left",
                            23250,
                            250,
                            "linear",
                            "${Text3}",
                            '54px',
                            '-271px'
                        ],
                        [
                            "eid470",
                            "top",
                            0,
                            0,
                            "linear",
                            "${Rectangle3}",
                            '373px',
                            '373px'
                        ],
                        [
                            "eid663",
                            "left",
                            6000,
                            500,
                            "linear",
                            "${Rectangle9}",
                            '-262px',
                            '54px'
                        ],
                        [
                            "eid665",
                            "left",
                            23250,
                            250,
                            "linear",
                            "${Rectangle9}",
                            '54px',
                            '-271px'
                        ],
                        [
                            "eid430",
                            "top",
                            1250,
                            750,
                            "linear",
                            "${Rectangle}",
                            '508px',
                            '477px'
                        ],
                        [
                            "eid438",
                            "top",
                            2000,
                            1000,
                            "linear",
                            "${Rectangle}",
                            '477px',
                            '403px'
                        ],
                        [
                            "eid443",
                            "top",
                            3000,
                            500,
                            "linear",
                            "${Rectangle}",
                            '403px',
                            '368px'
                        ],
                        [
                            "eid464",
                            "top",
                            5675,
                            325,
                            "linear",
                            "${Rectangle}",
                            '368px',
                            '316px'
                        ],
                        [
                            "eid677",
                            "top",
                            25000,
                            250,
                            "linear",
                            "${Text2}",
                            '539px',
                            '541px'
                        ],
                        [
                            "eid546",
                            "background-color",
                            15000,
                            250,
                            "linear",
                            "${RectangleCopy9}",
                            'rgba(192,192,192,1)',
                            'rgba(255,0,0,1.00)'
                        ],
                        [
                            "eid644",
                            "background-color",
                            23000,
                            250,
                            "linear",
                            "${RectangleCopy9}",
                            'rgba(255,0,0,1)',
                            'rgba(192,192,192,1.00)'
                        ],
                        [
                            "eid599",
                            "background-color",
                            20000,
                            500,
                            "linear",
                            "${EllipseCopy9}",
                            'rgba(209,209,209,1)',
                            'rgba(255,247,0,1)'
                        ],
                        [
                            "eid674",
                            "background-color",
                            20786,
                            292,
                            "linear",
                            "${EllipseCopy9}",
                            'rgba(255,247,0,1)',
                            'rgba(192,192,192,1.00)'
                        ],
                        [
                            "eid649",
                            "left",
                            5500,
                            500,
                            "linear",
                            "${Rectangle8}",
                            '50px',
                            '-234px'
                        ],
                        [
                            "eid678",
                            "left",
                            25000,
                            250,
                            "linear",
                            "${Rectangle8}",
                            '-234px',
                            '61px'
                        ]
                    ]
                }
            }
        };

    AdobeEdge.registerCompositionDefn(compId, symbols, fonts, scripts, resources, opts);

    if (!window.edge_authoring_mode) AdobeEdge.getComposition(compId).load("paralel_edgeActions.js");
})("EDGE-529728224");
