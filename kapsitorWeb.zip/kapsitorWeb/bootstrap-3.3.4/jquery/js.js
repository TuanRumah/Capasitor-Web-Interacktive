
$(document).ready(function(){
	function randomNumber(min, max){
		return Math.floor(Math.random() * (max - min + 1) + min);
		}
$('#captchaOperation').html([randomNumber(1,100), '+', randomNumber(1,200),'='].join(' '));

$('#basicBootstrapForm').formValidation({
	framework: 'bootstrap',
	icon :{
		valid: 'glyphicon glyphicon-ok',
		invalid: 'glyphicon glyphicon-remove',
		validating: 'glyphicon glyphicon-refresh'
		},
	fields:{
		firstName:{
			row: '.col-xs-4',
			validators:{
				notEmpty:{
					message:'Nama Depan tidak boleh kosong'
				}
			}
		},
		lastName:{
		//row: '.col-xs-4',
		validators:{
			notEmpty:{
				message:'Nama belakang tidak boleh kosong'
				}
			}
		},
		username:{
		validators:{
			notEmpty:{
				message: 'Nama tidak boleh kosong'
			},
			stringLength:{
				min:6,
				max:30,
				message: 'The username must be more than 6 and less than 30 characters long'
			},
			regexp:{
				regexp: /^[a-zA-Z0-9_\.]+$/,
				message: 'The username can only consist or alphabetical,number,dot and underscore'
				}
			}
		},
		email:{
			validators:{
				notEmpty:{
				message:'Email tidak boleh kosong'
				},
				emailAddress:{
				message: 'Email tidak valid'
				}
			}
		},
		password:{
		validators:{
			notEmpty:{
				message: 'Password tidak boleh kosong'
				},
			different:{
				field:'username',
				message:'The password cannot be the same as username'
				}
			}
		},
		gender:{
		validators:{
			notEmpty:{
				message: 'The gender is required'
				}
			}
		},
		captcha:{
			validators:{
				callback:{
				message:'Jawaban anda salah',
				callback: function(value,valiator,$field){
				var items=$('#captchaOperation').html().split(' '),sum=parseInt(items[0])+ parseInt(items[2]);
				return value == sum;
					}
				}
			}
		},
		agree:{
		validators:{
			notEmpty:{
			message:'Anda harus setuju dengan kondisi ini untuk melajutkan!'
						}
					}
			}
		}
	});
});